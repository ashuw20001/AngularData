from PythonTidy import VERSION

version = VERSION
summary = 'Cleans up, regularizes, and reformats the text of Python scripts.'
